# PRJ2025 > 2025-05-26 7:59pm
https://universe.roboflow.com/2025indai/prj2025

Provided by a Roboflow user
License: CC BY 4.0

